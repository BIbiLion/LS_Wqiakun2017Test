<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>QSRadar</name>
    <message>
        <location filename="../qsradar.cpp" line="26"/>
        <source>QSRadar</source>
        <comment>IRadar</comment>
        <translation>潜射</translation>
    </message>
</context>
</TS>
