/********************************Copyright(c)**********************************
                         http://www.holtek.com.tw

--------------------------------File Information-----------------------------
���W(File Name):lcd1602.h
����(Version):
���q�W(Company Name):
�������(Core Select):
-------------------------------------------------------------------------------
�@��(Author)�G���ͥ�
�Ыؤ��(Created Date):
�ק���(Last Modified Date):
�\��y�z(Descripton): 	
�����]�m(Mask Option):
****************************************************************************/
#include "c8051f340.h"

#define LCD_DATA_PORT  P0

sbit LCD_RS     =   	P3^3 ;  //RS
sbit LCD_EN     =    	P0^4 ;	//E
#define LCD_DATA       0xf0   	//P0^0/1/2/3   data out 

/*--------------------------------------------------------------------------------------------------
Public function prototypes
--------------------------------------------------------------------------------------------------*/
void delay					(unsigned long); 
void LCD_Init         		(void);
void LCD_Write_Char         (unsigned char,unsigned char);
void LCD_Write_Half_Char    (unsigned char);
void LCD_En_Write           (void);
void LCD_Set_xy             (unsigned char);
void LCD_Write_String       (unsigned char,unsigned char *);
void LCD_Write_Onechar      (unsigned char, unsigned char);
void LCD_Write_Continuechar (unsigned char);
void LCD_Write_Continuechar1(unsigned char,unsigned char *);
