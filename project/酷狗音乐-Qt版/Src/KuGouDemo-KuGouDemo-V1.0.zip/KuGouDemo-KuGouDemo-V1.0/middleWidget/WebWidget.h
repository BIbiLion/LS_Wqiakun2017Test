/*#ifndef WEBWIDGET_H
#define WEBWIDGET_H

#include <QObject>
#include <QWidget>
#include"baseWidget.h"
#include"qwebview.h"
class WebWidget : public baseWidget
{
public:
   explicit WebWidget(QWidget*p=0);
    QWebView *m_web;
};

#endif // WEBWIDGET_H*/

