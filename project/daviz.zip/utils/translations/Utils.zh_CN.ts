<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>RadarDisplay::FancyHeaderView</name>
    <message>
        <location filename="../fancyheaderview.cpp" line="12"/>
        <source>Adjust width</source>
        <translation>调整宽度</translation>
    </message>
    <message>
        <location filename="../fancyheaderview.cpp" line="13"/>
        <source>Auto resize</source>
        <translation>自动调整宽度</translation>
    </message>
</context>
</TS>
