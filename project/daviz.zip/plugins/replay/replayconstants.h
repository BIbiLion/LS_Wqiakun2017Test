#ifndef REPLAYCONSTANTS_H
#define REPLAYCONSTANTS_H

namespace {
static QString REPLAY_DIR_NAME = "replay";
}

#endif // REPLAYCONSTANTS_H
