#ifndef QSUTIL_H
#define QSUTIL_H

float eswapFloat(const float *f);

#endif // QSUTIL_H
