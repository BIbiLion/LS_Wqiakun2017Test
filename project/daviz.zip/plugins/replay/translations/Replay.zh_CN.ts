<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>RadarDisplay::RecordReplayWidget</name>
    <message>
        <location filename="../recordreplaywidget.cpp" line="172"/>
        <source>%1 to %2</source>
        <translation>%1到%2</translation>
    </message>
</context>
<context>
    <name>RadarDisplay::RecordWidget</name>
    <message>
        <location filename="../recordwidget.cpp" line="94"/>
        <source>Recording</source>
        <translation>记录中</translation>
    </message>
    <message>
        <location filename="../recordwidget.cpp" line="103"/>
        <source>Stopped</source>
        <translation>已停止</translation>
    </message>
</context>
<context>
    <name>RadarDisplay::ReplayPlugin</name>
    <message>
        <location filename="../replayplugin.cpp" line="45"/>
        <source>Record &amp; Replay</source>
        <translation>记录与回放</translation>
    </message>
</context>
<context>
    <name>RadarDisplay::ReplayRadar</name>
    <message>
        <location filename="../replayradar.cpp" line="27"/>
        <source>ReplayRadar</source>
        <translation>回放雷达</translation>
    </message>
    <message>
        <location filename="../replayradar.cpp" line="91"/>
        <location filename="../replayradar.cpp" line="124"/>
        <location filename="../replayradar.cpp" line="203"/>
        <location filename="../replayradar.cpp" line="223"/>
        <source>Bad replay file.</source>
        <translation>无效的记录文件。</translation>
    </message>
</context>
</TS>
