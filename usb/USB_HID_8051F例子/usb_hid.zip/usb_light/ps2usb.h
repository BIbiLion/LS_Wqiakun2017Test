

#ifndef _PS2USB_H_
#define _PS2USB_H_


void ShowString(void);

typedef /*code*/ struct
{
   unsigned char bModifier;              // Size of 
   unsigned char bReserved;      // Desc
   unsigned char bKeycode1;         // 
   unsigned char bKeycode2;      // 
   unsigned char bKeycode3;      // 
   unsigned char bKeycode4;      // M
   unsigned char bKeycode5;      // D
   unsigned char bKeycode6;      // 

} keyboard_code;  

typedef /*code*/ struct	 
{
    char bStart : 1;              // Size of 
    char bData  : 8;      // Desc
    char bOdd   : 1;         // 
    char bEnd   : 1;      // 
    char bAck   : 1;      // 
} ps2_code;  

extern keyboard_code KEYBOARD_CODE;
#endif