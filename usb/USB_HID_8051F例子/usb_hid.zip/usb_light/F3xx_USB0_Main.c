//-----------------------------------------------------------------------------
// F3xx_USB_Main.c
//-----------------------------------------------------------------------------
// Copyright 2005 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// This application will communicate with a PC across the USB interface.
// The device will appear to be a mouse, and will manipulate the cursor
// on screen.
//
// How To Test:    See Readme.txt
//
//
// FID:
// Target:         C8051F32x/C8051F340
// Tool chain:     Keil C51 7.50 / Keil EVAL C51
//                 Silicon Laboratories IDE version 2.6
// Command Line:   See Readme.txt
// Project Name:   F3xx_MouseExample
//
//
// Release 1.1
//    -Minor code comment changes
//    -16 NOV 2006
// Release 1.0
//    -Initial Revision (PD)
//    -07 DEC 2005
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include "c8051f340.h"
#include "data_type.h"
#include "F3xx_USB0_InterruptServiceRoutine.h"
#include "F3xx_USB0_Sys.h"
#include "F3xx_USB0_ReportHandler.h"
//#include "4x4key.h"
#include "lcd1602.h"

//#include "ps2usb.h"



unsigned char OUT_PACKET[20];


//-----------------------------------------------------------------------------
// Main Routine
//----------------------------------------------------------------------------- 
void main(void)
  {  
     //uint8  bsLength;
//	puint8 	 ShowString;
	
	OUT_BUFFER.Length = 17;
	OUT_BUFFER.Ptr = OUT_PACKET; 
	 

	        
//	Ps2USB_Init();
	System_Init ();
	USB0_Init(); 

	EA = 1;

	 LCD_Init();

////  
  	LCD_Write_Char(0,0x01); 
	delay(30);

	LCD_Write_String(0x85,"welcome ");
	LCD_Write_String(0xc4,"YUE SHSH!");
	delay(60000);
	LCD_Write_Char(0,0x01);
	delay(30);
	LCD_Write_String(0x85,"LET'S D! ");
	delay(60000);  
	 
 
	LCD_Write_Char(0,0x01);  
	delay(30);

	//  P2=0X00;
   while(1)
    {
      
		SendPacket (0);
	  
		ShowString();
 	}
}