// USB_HID_TESTDlg.cpp : implementation file
//

#include "stdafx.h"
#include "USB_HID_TEST.h"
#include "USB_HID_TESTDlg.h"
#include "stdlib.h"
//#include "string.h"


extern "C" 
{
#include "hidsdi.h" 
#include "setupapi.h"
}

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUSB_HID_TESTDlg dialog

CUSB_HID_TESTDlg::CUSB_HID_TESTDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUSB_HID_TESTDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUSB_HID_TESTDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CUSB_HID_TESTDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUSB_HID_TESTDlg)
	DDX_Control(pDX, IDC_COMBO_LINK, m_link);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CUSB_HID_TESTDlg, CDialog)
	//{{AFX_MSG_MAP(CUSB_HID_TESTDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FIND, ShowHIDAll)
	ON_BN_CLICKED(IDC_SEND, SendData)
	ON_BN_CLICKED(IDC_GET, GetData)
	ON_CBN_SELCHANGE(IDC_COMBO_LINK, CommunctionHID)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUSB_HID_TESTDlg message handlers

BOOL CUSB_HID_TESTDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
//	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
//	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
		

	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	
	// TODO: Add extra initialization here
	//IDC_COMBO_LINK reset
		((CComboBox*)GetDlgItem(IDC_COMBO_LINK))->ResetContent();//IDC_COMBO1
//	
	CRect rectSeparator;
	this->GetWindowRect(&rectLarge);
	GetDlgItem(IDC_SEPERATOR) ->GetWindowRect(&rectSeparator);

	rectSmall.left = rectLarge.left ;
	rectSmall.top = rectLarge.top ;
	rectSmall.bottom = rectLarge.bottom ;
	rectSmall.right = rectSeparator.right ;

	this->MoveWindow(&rectSmall);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CUSB_HID_TESTDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CUSB_HID_TESTDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CUSB_HID_TESTDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CUSB_HID_TESTDlg::ShowHIDAll()
{
	m_strLog.Empty();

	//IDC_COMBO_LINK reset
	((CComboBox*)GetDlgItem(IDC_COMBO_LINK))->ResetContent();//IDC_COMBO1

	//initialization text box
	SetDlgItemText(IDC_EDIT_VID,"");
	SetDlgItemText(IDC_EDIT_PID,"");
	SetDlgItemText(IDC_EDIT_VER,"");
	SetDlgItemText(IDC_EDIT_SEND,"");
	SetDlgItemText(IDC_EDIT_GET,"");

	//���üƾڵ��f
	SetWindowPos(NULL,0,0,rectSmall.Width (),rectSmall.Height (),
			SWP_NOMOVE|SWP_NOZORDER);


	m_strLog = _T("Find the GUID of HID...\r\n");
	SetDlgItemText(IDC_EDIT_REPORT,m_strLog);

	// ��oHID��GUID����
	GUID guidHID;
	HidD_GetHidGuid(&guidHID);
	m_strLog += _T("HID'GUID:\r\n");

	CString strShow;
	strShow.Format("%08x-%04x-%04x-%02x-%02x-%02x-%02x-%02x-%02x-%02x-%02x\r\n",
		guidHID.Data1,guidHID.Data2,guidHID.Data3,guidHID.Data4[0],
		guidHID.Data4[1],guidHID.Data4[2],guidHID.Data4[3],guidHID.Data4[4],
		guidHID.Data4[5],guidHID.Data4[6],guidHID.Data4[7]);
	//���GUID
	m_strLog += strShow;
	SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
	
	//�d��ŦXHID�W�d��USB�]��
	HDEVINFO hDevInfo = SetupDiGetClassDevs(&guidHID,NULL,0,
		DIGCF_PRESENT|DIGCF_DEVICEINTERFACE);
	if(hDevInfo==INVALID_HANDLE_VALUE)
	{
		m_strLog += _T("Find USB device error�I\r\n");
		SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
		return;
	}

//	UINT nIndex = 0;
	m_strLog += _T("Finding useful USB device...\r\n");
	SetDlgItemText(IDC_EDIT_REPORT,m_strLog);

	// �d��USB�]�Ʊ��f
	SP_DEVICE_INTERFACE_DATA strtInterfaceData;
	strtInterfaceData.cbSize=sizeof(SP_DEVICE_INTERFACE_DATA);

	BOOL bSuccess;
	UINT index = 1;
	//�`���d��A���]�]�Ƥ��W�L10�ӡC
	for(int i=0;i<10;i++)
	{
		bSuccess = SetupDiEnumDeviceInterfaces(hDevInfo,NULL,&guidHID,index,
														&strtInterfaceData);

		if (!bSuccess)
		{
			m_strLog += _T("Can't find useful USB device.\r\n");
			SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
			SetupDiDestroyDeviceInfoList(hDevInfo);
			break;
		}
		else
		{
			if(strtInterfaceData.Flags==SPINT_ACTIVE )
			{
				strShow.Format("\r\n%d link. \r\n",index);
				m_strLog +=strShow;
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);

				PSP_DEVICE_INTERFACE_DETAIL_DATA strtDetailData;

				DWORD strSzie=0,requiesize=0;
				SetupDiGetDeviceInterfaceDetail(hDevInfo,&strtInterfaceData,NULL,0,
												&strSzie,NULL);
				requiesize=strSzie;

				strtDetailData=(PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(requiesize);
				strtDetailData->cbSize=sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

				if (!SetupDiGetDeviceInterfaceDetail(hDevInfo,&strtInterfaceData,
										strtDetailData,strSzie,&requiesize,NULL))
				{
					m_strLog +=_T("Find USB device's path error!\r\n");
					SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
					SetupDiDestroyDeviceInfoList(hDevInfo);
					break;
				}
				
				//��ܳ]�ƪ����|.
				strShow.Format("device's path:\r\n%s\r\n\r\n",strtDetailData->DevicePath);
				m_strLog += strShow;
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);

				//���}�]�ơA����]�ƪ��y�`�C
				m_strLog += _T("Open the path...\r\n");
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
				
				//HANDLE hCom = CreateFile(
				 hCom[index] = CreateFile(
						strtDetailData->DevicePath,
						GENERIC_READ | GENERIC_WRITE,
						FILE_SHARE_READ | FILE_SHARE_WRITE,
						NULL,
						OPEN_EXISTING,
						0,//FILE_ATTRIBUTE_NORMAL,
						NULL);
				//�p�G�]�ƵL�ġA�h�h�X�C
				if (hCom[index] == INVALID_HANDLE_VALUE)
				{
					m_strLog +=_T("Can't open device!\r\n");
					SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
					SetupDiDestroyDeviceInfoList(hDevInfo);
					break;
				}

				m_strLog += _T("Open the path is OK!\r\n");
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
				
				//Ū���]�ƪ�ID.
				HIDD_ATTRIBUTES strtAttrib;
				m_strLog += _T("Reading the device's ID...\r\n");
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
				if (!HidD_GetAttributes(hCom[index],&strtAttrib))
				{
					m_strLog +=_T("Find the device' ID error!\r\n");
					SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
					CloseHandle(hCom[index]);
					SetupDiDestroyDeviceInfoList(hDevInfo);
					break;
				}

				m_strLog += _T("Read ID OK, as follow:\r\n");
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);

				//���ID
				strShow.Format("VendorID:0x%X\r\nProductID:0x%X\r\nVersionNumber:0x%X\r\n",
						strtAttrib.VendorID,strtAttrib.ProductID,strtAttrib.VersionNumber);
				m_strLog +=strShow;
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
				
				//
			/*	if(!HidD_GetIndexedString(hCom[index],0,0,0))
				{
					m_strLog +=_T("Get device name error!\r\n");
					SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
					break;
				}
*/

				//�b�U�Ԯؤ��K�[�s����
				strShow.Format("link %d",index);
				((CComboBox*)GetDlgItem(IDC_COMBO_LINK))->AddString(strShow);

				index++;
			}
		}	
	}

	strShow.Format("\r\nTotal:\r\n%d devices\r\n",index);
	m_strLog += strShow;
	SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
	m_strLog += _T("============================\r\n\n\n");
	SetDlgItemText(IDC_EDIT_REPORT,m_strLog);

}

void CUSB_HID_TESTDlg::CommunctionHID()
{
	CString strTemp,strLink;
	
	m_link.GetLBText(m_link.GetCurSel(),strTemp);

	if(strTemp == "link 1")
	{
	
		HIDD_ATTRIBUTES strtAttrib;

		if (!HidD_GetAttributes(hCom[1],&strtAttrib))
		{
			CloseHandle(hCom);
			return;
		}
		CString strShow;
		strShow.Format("0x%X",strtAttrib.VendorID);
		SetDlgItemText(IDC_EDIT_VID,strShow);

		strShow.Format("0x%X",strtAttrib.ProductID);
		SetDlgItemText(IDC_EDIT_PID,strShow);

		strShow.Format("0x%X",strtAttrib.VersionNumber);
		SetDlgItemText(IDC_EDIT_VER,strShow);

		/////////////
		

		//>><<

		SetWindowPos(NULL,0,0,rectLarge.Width (),rectLarge.Height (),
			SWP_NOMOVE|SWP_NOZORDER);
	}

}

void CUSB_HID_TESTDlg::SendData()
{
	CString strVID,strPID,strSend;
	char string[20]={0,0,};

	GetDlgItemText(IDC_EDIT_VID,strVID);
	GetDlgItemText(IDC_EDIT_PID,strPID);
	if ((strVID=="0x6655") && (strPID="0x800A") )
	{				
		BOOL bResult=0;
		unsigned long nBytesRead=0;
		unsigned char bOrder[19]={0,0,5,'a','b','c','d','e',};

		GetDlgItemText(IDC_EDIT_SEND,strSend);

		if(strSend.GetLength()<32)
		{
			string[2]=strSend.GetLength();	
			strcpy(&string[3],strSend);
			bResult = WriteFile(hCom[1],string,19,&nBytesRead,NULL);

			if(!bResult && nBytesRead==0)
			{
				m_strLog += _T("Send data error!\r\n");
				SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
				return;
			}
			m_strLog += _T("\r\nSend data:");
			SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
			m_strLog += strSend;
			SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
			m_strLog += _T("\r\nSend data OK!\r\n");
			SetDlgItemText(IDC_EDIT_REPORT,m_strLog);

		}
		else
		{
			m_strLog += _T("\r\nMore than 17 character!\r\nPlease input again!!!!\r\n");
			SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
		}
	
		SetDlgItemText(IDC_EDIT_SEND,"");

	}
}

void CUSB_HID_TESTDlg::GetData()
{
	CString strVID,strPID,strGet;

	GetDlgItemText(IDC_EDIT_VID,strVID);
	GetDlgItemText(IDC_EDIT_PID,strPID);
	if ((strVID=="0x6655") && (strPID=="0x800A") )
	{
		unsigned char bOrder[20];
		BOOL bResult=0;
		unsigned long nBytesRead=0;
		bResult = ReadFile(hCom[1],bOrder,8,&nBytesRead,NULL);
		if(!bResult && nBytesRead==0)
		{
			m_strLog += _T("Get data error!\r\n");
			SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
			return;
		}
		bOrder[nBytesRead]=0;
		strGet=bOrder+1;
		SetDlgItemText(IDC_EDIT_GET,strGet);

		m_strLog += _T("\r\nGet data OK!\r\n");
		SetDlgItemText(IDC_EDIT_REPORT,m_strLog);
		
	}
}


