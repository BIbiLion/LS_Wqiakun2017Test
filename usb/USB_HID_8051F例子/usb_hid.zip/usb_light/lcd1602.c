/********************************Copyright(c)**********************************
                         http://www.holtek.com.tw

****************************************************************************/
#include "c8051f340.h"
#include "lcd1602.h"

unsigned char data_continue;


void delay(unsigned long d)                 //
  {
    for(;d;d--);
  }

/*-----------------------------------------------------------------------
Function	: LCD_Init()
Parameters	: none
Return 		: none
Description	: initalization LCD1602,
-----------------------------------------------------------------------*/
void LCD_Init(void) 
  {  
	LCD_EN=0;
  	delay(1000);                  
  	LCD_Write_Char(0,0x30);  
  	delay(5000); 
  	LCD_Write_Char(0,0x30);        
  	delay(5000);  
  	LCD_Write_Char(0,0x30);         
  	delay(5000);   
  	LCD_Write_Char(0,0x02);                
  	delay(5000);   
  	LCD_Write_Char(0,0x28); 	//4bit test  
  	delay(5000);    
  	LCD_Write_Char(0,0x08);         // 
  	delay(5000); 
  	LCD_Write_Char(0,0x01);         //��  
  	delay(5000);   
  	LCD_Write_Char(0,0x06);         //
  	delay(5000); 
  	LCD_Write_Char(0,0x0c);         // 
  	delay(50000);    
  }
  
/*-----------------------------------------------------------------------
Function	: LCD_Init()
Parameters	: none
Return 		: none
Description	: initalization LCD1602,
-----------------------------------------------------------------------*/  
void LCD_En_Write(void) 
 {
  	LCD_EN=1;		
  	delay(1);
  	LCD_EN=0;
 }
 
/*-----------------------------------------------------------------------
Function	: LCD_Write_Char()
Parameters	: command:0--instruction;1--data;data1--code
Return 		: none
Description	: writer a instruction or data to LCD1602
-----------------------------------------------------------------------	   */

void LCD_Write_Char(unsigned char command,unsigned char data1)
  {  
  	LCD_EN=0;    
  	if (command == 0)				//if instruction?
   	 	LCD_RS=0;					//send instruction,RS=0
	else
   		LCD_RS=1;					//send data ,RS=1
			
   	LCD_Write_Half_Char(data1>>4); 	//first,send high 4bit of the data				
  	LCD_Write_Half_Char(data1);	  	//then send low 4bit of the data
	delay(2000);	 
  }
  
/*-----------------------------------------------------------------------
Function	: LCD_Write_Half_Char()
Parameters	: half_value
Return 		: none
Description	: 4bits send,high 4bits  then low 4bits
-----------------------------------------------------------------------	  */
void LCD_Write_Half_Char(unsigned char half_value)
  {
   	 LCD_DATA_PORT &= 0Xf0; 			//initalization data port0~3=0 
   	 LCD_DATA_PORT |= half_value&0x0f; 	//send LOW 4bit
	 LCD_En_Write();					//give a high pulse
   	 LCD_DATA_PORT &= 0Xf0; 			//initalization data port0~3=0 
	 delay(1000);
   }


/*-----------------------------------------------------------------------
Function	: LCD_Set_xy()
Parameters	: address: 	row 1:0x80--0x8f
         				row 2:0xc0--0xcf
Return 		: none
Description	: where LCD should show the character
-----------------------------------------------------------------------*/

void LCD_Set_xy( unsigned char address)
  { 
       LCD_Write_Char(0,address);
  }  
  
/*-----------------------------------------------------------------------
Function	: LCD_Write_String()
Parameters	: address: 	row 1:0x80--0x8f
         				row 2:0xc0--0xcf
			  *s:      	character string 
Return 		: none
Description	: show the string
-----------------------------------------------------------------------*/

void LCD_Write_String(unsigned char address,unsigned char *s)
  {
   	LCD_Set_xy(address );
    while (*s) 
      {
      	LCD_Write_Char(1,*s);
		s ++;
      }
  }
  
/*-----------------------------------------------------------------------
Function	: LCD_Write_Onechar()
Parameters	: address: 	row 1:0x80--0x8f
         				row 2:0xc0--0xcf
			  data1:    one	character
Return 		: none
Description	: show one character
-----------------------------------------------------------------------*/ 
void LCD_Write_Onechar(unsigned char address,unsigned char data1)
  {
 	LCD_Set_xy(address);
 	LCD_Write_Char(1, data1);
  }

/*-----------------------------------------------------------------------
Function	: LCD_Write_Continuechar()
Parameters	: data1
Return 		: none
Description	: 
---------------------------------------------------------------------- */
void LCD_Write_Continuechar(unsigned char data1)
  {
  	if(data_continue<16)
  	  {
  	  	LCD_Set_xy(0x80+data_continue++);
   		LCD_Write_Char(1,data1);
  	  }
  	else if((data_continue>15) && (data_continue<32))
  	  {
   		LCD_Set_xy(0xb0+data_continue++);
   		LCD_Write_Char(1,data1);
  	  }
  	else
  		data_continue =0;
 }

/*-----------------------------------------------------------------------
Function	: LCD_Write_Continuechar1()
Parameters	: none
Return 		: none
Description	: 
-----------------------------------------------------------------------	 */
void LCD_Write_Continuechar1(unsigned char number,unsigned char *data1)
  {
  	char i;
  	for(i=0;i<number;i++)
  	  {
   		if(data_continue<16)
    		LCD_Write_Onechar(0x80+data_continue++,data1[i]);
  		else if((data_continue>15)&&(data_continue<32))
    		LCD_Write_Onechar(0xb0+data_continue++,data1[i]);
  		else
   			data_continue =0;
  	  }
	data_continue =0;
  }
  						