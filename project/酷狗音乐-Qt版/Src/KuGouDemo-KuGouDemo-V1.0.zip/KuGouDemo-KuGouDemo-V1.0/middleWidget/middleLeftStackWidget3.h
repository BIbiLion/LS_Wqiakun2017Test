#ifndef MIDDLELEFTSTACKWIDGET3_H
#define MIDDLELEFTSTACKWIDGET3_H

#include <QObject>
#include <QWidget>
#include"baseWidget.h"
class middleLeftStackWidget3:public baseWidget
{
    Q_OBJECT
public:
   explicit middleLeftStackWidget3(QWidget *parent);
    void initLayout();
};

#endif // MIDDLELEFTSTACKWIDGET3_H
