#include "Global_ValueGather.h"

#include"mainwindow.h"
#include"middleLeftStackWidget0.h"
#include"FFmpegPlayer.h"
#include"deskTopLrcWidget.h"
#include"lyriclabel.h"
#include"basewindow.h"

/*
 * Do not add static keyword at the beginning of the data ,only to let the data used in this file
*/
mainWindow *mainwid=NULL;

middleLeftStackWidget0* midstack0Pointer=NULL;

FFmpegPlayer* ffplayerPointer=NULL;

deskTopLrcWidget *desktoplrcPointer=NULL;

LyricLabel *lyriclabelPointer=NULL;

Widget *backgroundPointer=NULL;
