/*#include "WebWidget.h"
#include"QHBoxLayout"
WebWidget::WebWidget(QWidget*p):baseWidget(p)
{
    m_web=new QWebView(this);
    m_web->setStyleSheet("background:white;");
    QHBoxLayout *m_layout=new  QHBoxLayout;
    m_layout->addWidget(m_web);
    m_layout->setContentsMargins(0,1,2,0);
    setLayout(m_layout);
}*/


