<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>RadarDisplay::TestRadar</name>
    <message>
        <location filename="../testradar.cpp" line="22"/>
        <source>Test</source>
        <comment>IRadar</comment>
        <translation>测试</translation>
    </message>
</context>
</TS>
