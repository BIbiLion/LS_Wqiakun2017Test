/********************************Copyright(c)**********************************
                         http://www.holtek.com.tw

--------------------------------File Information-----------------------------
** File Name:
** Last modified Date: 
** Last Version: 
** Description:
** 
**------------------------------------------------------------------------------------------------------
** Created By: yue sheng sheng
** Created date: 2006-11-15 
** Version: 
** Descriptions:
**
**------------------------------------------------------------------------------------------------------
** Modified by:
** Modified date:
** Version:
** Description:
**
********************************************************************************************************/
#ifndef __DATA_TYPE_H 
#define __DATA_TYPE_H

//#ifndef _WORD_DEF_                     // Compiler Specific, written
//#define _WORD_DEF_
//typedef unsigned short 	WORD;
//#endif	// _WORD_DEF_
typedef unsigned char  	uint8;                   /* defined for unsigned 8-bits integer variable 	*/
typedef signed   char  	int8;                    /* defined for signed 8-bits integer variable		*/
//typedef unsigned short 	uint16;                  /* defined for unsigned 16-bits integer variable  	*/
//typedef signed   short 	int16;                   /* defined for signed 16-bits integer variable 		*/
typedef unsigned int   	uint16;                  /* defined for unsigned 16-bits integer variable 	*/
typedef signed   int   	int16;                   /* defined for signed 16-bits integer variable 		*/
typedef unsigned long   uint32;                  /* defined for unsigned 32-bits integer variable 	*/
typedef signed   long   int32;                   /* defined for signed 32-bits integer variable 		*/
typedef float          	fp32;                    /* single precision floating point variable (32bits)  	*/
//typedef double         	fp64;                    /* double precision floating point variable (64bits)  	*/
typedef char  BOOL;

typedef int8 			* pint8;
typedef uint8 			* puint8;
typedef int16			* pint16;
typedef uint16			* puint16;
typedef int32			* pint32;
typedef uint32			* puint32;
typedef void			* pvoid;

///////////////////////////////////////////////////////////////
// Boolean value definition
//
#define TRUE			((char) 1)
#define FALSE			((char) 0)


//#define CLR_FLAG(X,FLAG) X &= ~(FLAG)
//#define SET_FLAG(X,FLAG) X |= (FLAG)

/////////////////////////////////////////////////////////////
// count the element of an array

#define MAKEWORD(a, b)      ((uint16)(((uint8)((uint32)(a) & 0xff)) | ((uint16)((uint8)((uint32)(b) & 0xff))) << 8))
//#define MAKELONG(a, b)      ((uint32)(((uint16)((uint32)(a) & 0xffff)) | ((uint32)((uint16)((uint32)(b) & 0xffff))) << 16))
//#define MAKEWORD(a, b)      (((uint16)(a) & 0xff) | (((uint16)(b) & 0xff) << 8))
#define MAKELONG(a, b)      ((uint32)(((uint16)((uint32)(a) & 0xffff)) | ((uint32)((uint16)((uint32)(b) & 0xffff))) << 16))
#define LOWORD(l)           ((uint16)((uint32)(l) & 0xffff))
#define HIWORD(l)           ((uint16)((uint32)(l) >> 16))
#define LOBYTE(w)           ((uint8)((uint32)(w) & 0xff))
#define HIBYTE(w)           ((uint8)((uint32)(w) >> 8))

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif


#endif
