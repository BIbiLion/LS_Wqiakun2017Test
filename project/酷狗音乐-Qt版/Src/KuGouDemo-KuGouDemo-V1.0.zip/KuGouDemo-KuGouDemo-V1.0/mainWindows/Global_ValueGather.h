#ifndef GOBAL_POINTERGATHER_H
#define GOBAL_POINTERGATHER_H

class mainWindow;
class middleLeftStackWidget0;
class FFmpegPlayer;
class deskTopLrcWidget;
class LyricLabel;
class Widget;



extern mainWindow *mainwid;

extern middleLeftStackWidget0* midstack0Pointer;

extern FFmpegPlayer* ffplayerPointer;

extern deskTopLrcWidget *desktoplrcPointer;

extern LyricLabel *lyriclabelPointer;

extern Widget *backgroundPointer;

#endif // GOBAL_POINTERGATHER_H
