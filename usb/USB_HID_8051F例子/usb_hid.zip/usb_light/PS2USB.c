/********************************Copyright(c)**********************************
                         http://www.holtek.com.tw

--------------------------------File Information-----------------------------
���W(File Name):PS2.c
����(Version):
���q�W(Company Name):
�������(Core Select):
-------------------------------------------------------------------------------
�@��(Author)�G���ͥ�
�Ыؤ��(Created Date):
�ק���(Last Modified Date):
�\��y�z(Descripton): 	
�����]�m(Mask Option):Fsys=4MHZ,
****************************************************************************/
#include "c8051f340.h"
#include "lcd1602.h"
#include "data_type.h"
#include "ps2usb.h"

#include <intrins.h>
//#include <intrins.h>
//#include <stdlib.h>

keyboard_code 	KEYBOARD_CODE;

//key_modifier 	KEY_MODIFIER;
extern unsigned char OUT_PACKET[20];
uint8 sLength;
puint8 LCDString;

void Get_P2_Stater(void)
{

}

void ShowString(void)
{
	
	if(!OUT_PACKET[0])
	  {
	  	sLength = OUT_PACKET[1];
		LCDString = &OUT_PACKET[2];
		LCD_Write_Char(0,0x01);  
		delay(30);
		OUT_PACKET[0]=0xff;

		LCD_Write_Continuechar1(sLength,LCDString);

	  }
}
/*	 // Get_P2_Stater();
	  
	   	 	 */


 
