/* ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
 * ┃     ┏━┣━┣┓　　┏┓┏┓┳┓┏━━┓┣┣━┓　┓　┓┣┳━┓       ┃
 * ┃     ┏┏┏╯━┓┳┳━┛┏╯┃┃┃　　┃┣┣━┓┃┃　┃┃┃　　       ┃
 * ┃     ┃┃┏━╮┃┗┗┏╯┗┃┃╯┃　　┃┏┣━┓┃┃　┃╯┣━┓       ┃
 * ┃     ╰┫┏━┻╯┗┳┣┛┏┛┃┃┣━━┫┃┃　┃┃┃┗╯　┃　　       ┃
 * ┃     ┏┫━┳━┫┏┃┣┓┗┃┃╯┃　　┃┃┃　┃　┃　┃　┣━┓       ┃
 * ┃     ┗┗┗━━╯┗┛┛╯┗╯╰　┗━━╯　┛　┛┗╯　╰┛┗　　       ┃
 * ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
 * ┃                     Copyright (c) 2013 jiangcaiyang                    ┃
 * ┃ This software is provided 'as-is', without any express or implied      ┃
 * ┃ warranty. In no event will the authors be held liable for any damages  ┃
 * ┃ arising from the use of this software.                                 ┃
 * ┃                                                                        ┃
 * ┃ Permission is granted to anyone to use this software for any purpose,  ┃
 * ┃ including commercial applications, and to alter it and redistribute it ┃
 * ┃ freely, subject to the following restrictions:                         ┃
 * ┃                                                                        ┃
 * ┃ 1. The origin of this software must not be misrepresented; you must    ┃
 * ┃    not claim that you wrote the original software. If you use this     ┃
 * ┃    software in a product, an acknowledgment in the product             ┃
 * ┃    documentation would be appreciated but is not required.             ┃
 * ┃ 2. Altered source versions must be plainly marked as such, and must    ┃
 * ┃    not be misrepresented as being the original software.               ┃
 * ┃ 3. This notice may not be removed or altered from any source           ┃
 * ┃    distribution.                                                       ┃
 * ┃                                                                        ┃
 * ┃ jiangcaiyang jiangcaiyang123@163.com                                   ┃
 * ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
 * ┃ file name: Camera.h                                                    ┃
 * ┃ create date: 2013年8月24日星期六 23时28分46秒                          ┃
 * ┃ last modified date: 2013年8月24日星期六 23时28分46秒                   ┃
 * ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
 */
#ifndef CAMERA_H
#define CAMERA_H

#include <QVector3D>

/*---------------------------------------------------------------------------*/
class Camera
{
public:
    Camera( void );
    void SetPos( const QVector3D pos, bool _try = false );
    inline QVector3D& Pos( void ) { return m_Pos; }
    inline QVector3D& Len( void ) { return m_Len; }
    inline float& RotateY( void ) { return m_RotateY; }
    inline float& RotateH( void ) { return m_RotateH; }
    void SetRotateY( float rotateY, bool _try = false );
    void SetRotateH( float rotateH, bool _try = false );
    void ZoomIn( float step );

    void Apply( void );
private:
    QVector3D           m_Pos;
    QVector3D           m_Len;
    float               m_RotateY, m_RotateH;

    // 尝试的部分
    QVector3D           m_TryPos, m_Offset2D;
    float               m_TryRotateY, m_TryRotateH;
    bool                m_Try;
};
/*---------------------------------------------------------------------------*/
#endif // CAMERA_H
