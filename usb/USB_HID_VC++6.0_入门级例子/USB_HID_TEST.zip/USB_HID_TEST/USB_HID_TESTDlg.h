// USB_HID_TESTDlg.h : header file
//

#if !defined(AFX_USB_HID_TESTDLG_H__B81C1BF8_54D3_45D7_B31B_C91AD63D48C3__INCLUDED_)
#define AFX_USB_HID_TESTDLG_H__B81C1BF8_54D3_45D7_B31B_C91AD63D48C3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CUSB_HID_TESTDlg dialog

class CUSB_HID_TESTDlg : public CDialog
{
// Construction
public:
	
	HANDLE hCom[10];
	CString m_strLog;
	CRect rectLarge;
	CRect rectSmall;
	CUSB_HID_TESTDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CUSB_HID_TESTDlg)
	enum { IDD = IDD_USB_HID_TEST_DIALOG };
	CComboBox	m_link;
//	HIDD_ATTRIBUTES strtAttrib;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUSB_HID_TESTDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CUSB_HID_TESTDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void ShowHIDAll();
	afx_msg void SendData();
	afx_msg void GetData();
	afx_msg void CommunctionHID();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USB_HID_TESTDLG_H__B81C1BF8_54D3_45D7_B31B_C91AD63D48C3__INCLUDED_)
