#ifndef TRACK_H
#define TRACK_H

namespace RadarDisplay {

struct TrackData
{
    TrackData() {}
    TrackData(int _id) : id(_id) {}
    int id;
};

}

#endif // TRACK_H
