#include "mainform.h"
#include <QApplication>
#include <QDir>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //设置程序路径为相对路径
    QDir::setCurrent(QApplication::applicationDirPath());
    MainForm w;
    w.show();

    return a.exec();
}
