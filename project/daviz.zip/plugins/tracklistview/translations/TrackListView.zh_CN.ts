<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>RadarDisplay::TrackListViewPlugin</name>
    <message>
        <location filename="../tracklistviewplugin.cpp" line="36"/>
        <source>Track List</source>
        <translation>航迹列表</translation>
    </message>
</context>
<context>
    <name>TrackListModel</name>
    <message>
        <location filename="../tracklistmodel.cpp" line="23"/>
        <source>ID</source>
        <translation>编号</translation>
    </message>
    <message>
        <location filename="../tracklistmodel.cpp" line="24"/>
        <source>R</source>
        <translation>距离</translation>
    </message>
    <message>
        <location filename="../tracklistmodel.cpp" line="25"/>
        <source>A</source>
        <translation>方位</translation>
    </message>
    <message>
        <location filename="../tracklistmodel.cpp" line="26"/>
        <source>E</source>
        <translation>仰角</translation>
    </message>
    <message>
        <location filename="../tracklistmodel.cpp" line="27"/>
        <source>H</source>
        <translation>高度</translation>
    </message>
    <message>
        <location filename="../tracklistmodel.cpp" line="28"/>
        <source>O</source>
        <translation>航向</translation>
    </message>
    <message>
        <location filename="../tracklistmodel.cpp" line="29"/>
        <source>V</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../tracklistmodel.cpp" line="30"/>
        <source>T</source>
        <translation>时间</translation>
    </message>
</context>
</TS>
